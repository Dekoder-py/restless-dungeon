import game

def main():
    game.Game().run()