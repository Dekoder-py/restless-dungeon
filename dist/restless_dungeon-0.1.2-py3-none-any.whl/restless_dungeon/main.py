from game import Game

def main():
    game = Game()
    game.run()