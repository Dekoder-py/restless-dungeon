from restless_dungeon.game import Game

def main():
    game = Game()
    game.run()